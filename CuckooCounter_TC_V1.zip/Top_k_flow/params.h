#ifndef _PARAMS_H
#define _PARAMS_H

#define N 1000000  // maximum flow
#define M 1000000  // maximum size of stream-summary
#define MAX_MEM 1000000 // maximum memory size
#define HK_d 2 // maximum memory size

#endif //_PARAMS_H
