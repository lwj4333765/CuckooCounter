# Cuckoo_Counter Frequency Estimation

## How to run

Suppose you've already cloned the repository.

You just need:

```
$ make 
$ ./cuckoo ./XX.data
```

`XX.data` is a dataset.

## Output format

Our program will print the throughput of insertion and query of these four sketches and the Cuckoo Counter, and the ARE and AAE of these sketches and the Cuckoo Counter.